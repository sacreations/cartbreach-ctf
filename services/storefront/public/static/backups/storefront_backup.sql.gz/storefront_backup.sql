-- CartBreach Database Backup (Automated Snapshot)
-- Generated: 2026-03-01 03:00:00 UTC
-- Host: postgres-data.cartbreach.local

SET statement_timeout = 0;
SET client_encoding = 'UTF8';

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(128) NOT NULL,
    email character varying(128),
    role character varying(16)
);

COPY users (id, username, password_hash, email, role) FROM stdin;
1	guest	$2b$10$K8P2YVmGxLqNt3RwZuB1eOQkJ5hMvXsYdFnCpA7iWo6lTe9rI0mUq	guest@cartbreach.local	guest
2	admin	$2b$10$w3vQ9Xm4KpLzRnT2YuB0eOQkJ5hMvXsYdFnCpA7iWo6lTe9rI0mUq	admin@cartbreach.local	admin
\.

CREATE TABLE system_service_keys (
    id integer NOT NULL,
    key_name character varying(64) NOT NULL,
    encrypted_value text NOT NULL,
    description text
);

COPY system_service_keys (id, key_name, encrypted_value, description) FROM stdin;
1	internal_api_token	cb_internal_svc_t0k3n_4dm1n	SLIIT{c4rt_br34ch_f0r3n51c_db_dump} — Cracked passphrase: harvest2026
\.
